import Foundation


func noArgumentsAndNoRetunValues () {
    "I don't know what I am doing.."
}

noArgumentsAndNoRetunValues()

func plusTwo(value: Int) {
    let newValue = value + 2
}

plusTwo(value: 20)


@discardableResult
func newPlusTwo(value: Int) -> Int {
    value + 3
}


func customAdd(
    value1: Int,
    value2: Int) -> Int {
        value1 + value2
    }


customAdd(value1: 3, value2: 2)

func customMinus(
   _ value1: Int,
   _ value2: Int) -> Int {
        value1 - value2
    }

customMinus(5, 3)


func doSomethingComplicated( with value0: Int) -> Int {
    func mainLogic(value6: Int) -> Int {
        value6 + 2
    }
    return mainLogic(value6:  value0 + 5)
}


doSomethingComplicated(with: 33)

func getFullName(
    firstName: String = "Foo",
    lastName: String = "Bar") -> String {
        "\(firstName) \(lastName)"
    }

getFullName()
getFullName(firstName: "Sari")
getFullName(lastName: "Siraj")
getFullName(firstName: "Sari", lastName: "Siraj")



    


