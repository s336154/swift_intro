import Foundation


let myName = "Sari"
let myAge = 31
let yourName = "Vandad"
let yourAge = 24


if myName == "Vandad" && myAge > 35 {
    "I am senior fullstack developer"
} else if yourName == "Vandad" && yourAge > 35 {
    "You are a senior fullstack developer"
} else {
    "Neither of the two cases applys to a senior Fullsatck developer"
}

